import { XmlTree } from "./types";

export default async function initializeStateTree(
  xmlTree: XmlTree
): Promise<XmlTree> {
  return xmlTree;
}
