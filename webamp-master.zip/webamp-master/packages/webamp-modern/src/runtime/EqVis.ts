import GuiObject from "./GuiObject";

class EqVis extends GuiObject {
  /**
   * getClassName()
   *
   * Returns the class name for the object.
   * @ret The class name.
   */
  getclassname() {
    return "EqVis";
  }
}

export default EqVis;
