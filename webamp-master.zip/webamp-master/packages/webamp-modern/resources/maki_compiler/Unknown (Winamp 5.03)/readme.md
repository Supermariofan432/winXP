Scraped from https://web.archive.org/web/20051122102353/http://bluemars.planet-d.net/sdk/ wich was discovered via a link in Objects.pm from the decompiler.

The server had a number of binary files as well, which sadly the Internet Archvie did not capture.

wasabi-sdk500-b3.exe
wasabi-sdk499g8.exe
maki/mc.exe
