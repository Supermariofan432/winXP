# Credits

## Music

Music courtesy of [blocSonic](https://blocsonic.com) and all included netBloc artists. [Download your free copy of "netBloc Volume 24 (tiuqottigeloot)"](https://blocsonic.com/releases/bscomp0024).

## Milkdrop Visualization

The Milkdrop visualization window is provided by the [Butterchurn](https://butterchurnviz.com/) project which was built and integrated, by [Jordan Berg](https://twitter.com/jnberg16).
