# Changelog for `ani-cursor`

## Next (unreleased)

### Bug Fixes

* Prevent "Maximum call stack size exceeded" error when parsing large cursors.

## 0.0.5

### Bug Fixes

* Allow the parser to find frames inside the info chunk. I believe cursors made using http://take1.de put the frame info there.

## 0.0.4

Initial Published Release